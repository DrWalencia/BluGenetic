#!/usr/bin/env perl 
#===============================================================================
#
#         FILE: BitVectorExample.pl
#
#        USAGE: ./BitVectorExample.pl  
#
#  DESCRIPTION: Example on how to use BluGenetic.
#  
#               It consists of a genetic algorithm using the BitVector data
#               type promoting those individuals whose genotype contains the
#               highest amount of ones.
#
#               All kinds of crossover/selection strategies can and must be
#               tried. Also custom strategies can be declared.
#  
#
#       AUTHOR: Pablo Valencia González (PVG), valeng.pablo@gmail.com
# ORGANIZATION: Universidad de León
#      VERSION: 1.0
#      CREATED: 08/20/2013 12:33:51 AM
#     REVISION: ---
#===============================================================================

use BluGenetic;

sub fitness {

    ($individual) = @_;
    $genotype = $individual->getGenotype();
    $counter = 0;

    for ( $i = 0 ; $i < $genotype->getLength() ; $i++ ) {
        $counter += $genotype->getGen($i);
    }

    return $counter;
}

$algorithm = BluGenetic->new(
    popSize     => 20,
    crossProb   => 0.9,
    mutProb     => 0.06,
    type        => 'BitVector',
    myFitness   => \&fitness,
);


$algorithm->initialize(20);

$algorithm->evolve(
    selection   => "roulette",
    crossover   => "uniform",
    generations => 10,
);

$ind = $algorithm->getFittest();
$genotype = $ind->getGenotype();


print "Score of fittest: \t ", $ind->getScore(), "\n";
print "Genotype of fittest: \t ";

for ( $t = 0; $t < $genotype->getLength(); $t++ ){
    print $genotype->getGen($t);
}

print "\n";