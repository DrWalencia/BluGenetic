#!/usr/bin/env perl 
#===============================================================================
#
#         FILE: RangeVectorExample.pl
#
#        USAGE: ./RangeVectorExample.pl  
#
#  DESCRIPTION: Example on how to use BluGenetic
#
#               It consists of a genetic algorithm using the RangeVector data
#               type promoting those individuals whose sum of the integer 
#               numbers composing their genotype gives the highest number.
#
#      OPTIONS: ---
# REQUIREMENTS: ---
#         BUGS: ---
#        NOTES: ---
#       AUTHOR: Pablo Valencia González (PVG), valeng.pablo@gmail.com
# ORGANIZATION: Universidad de León
#      VERSION: 1.0
#      CREATED: 08/20/2013 11:58:27 PM
#     REVISION: ---
#===============================================================================

use BluGenetic;

sub fitness {

    $individual = $_[0];
    $genotype = $individual->getGenotype();
    $counter = 0;

    for ( $i = 0 ; $i < $genotype->getLength() ; $i++ ) {
        $counter += $genotype->getGen($i);
    }

    return $counter;
}

$algorithm = BluGenetic->new(
    popSize     => 20,
    crossProb   => 0.8,
    mutProb     => 0.05,
    type        => 'RangeVector',
    myFitness   => \&fitness,
);

$algorithm->initialize( [ 1, 5 ], [ 0, 20 ], [ 4, 9 ] );

$algorithm->evolve(
    selection   => "roulette",
    crossover   => "onepoint",
    generations => 20
);

$ind = $algorithm->getFittest();
$genotype = $ind->getGenotype();

print "Score of fittest: \t", $ind->getScore(), "\n";

print "Genotype of fittest: \t";

for ( $i = 0; $i < $genotype->getLength(); $i++ ){
    print $genotype->getGen($i), " ";
}

print "\n";
