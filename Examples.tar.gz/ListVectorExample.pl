#!/usr/bin/env perl 
#===============================================================================
#
#         FILE: ListVectorExample.pl
#
#        USAGE: ./ListVectorExample.pl  
#
#  DESCRIPTION: Example on how to use BluGenetic
#
#               It consists of a genetic algorithm using the ListVector datat
#               type promoting those individuals whose genotype contains
#               the longest strings.
#
#               All kinds of crossover/selection strategies can and must be
#               tried. Also custom strategies can be declared.
#
#      OPTIONS: ---
# REQUIREMENTS: ---
#         BUGS: ---
#        NOTES: ---
#       AUTHOR: Pablo Valencia González (PVG), valeng.pablo@gmail.com
# ORGANIZATION: Universidad de León
#      VERSION: 1.0
#      CREATED: 08/21/2013 12:12:50 AM
#     REVISION: ---
#===============================================================================

use BluGenetic;

sub fitness {

    $individual = $_[0];
    $genotype = $individual->getGenotype();
    $counter = 0;

    for ( $i = 0 ; $i < $genotype->getLength() ; $i++ ) {
        $temp = $genotype->getGen($i);
        $counter += length $temp;
    }

    return $counter;
}

$algorithm = BluGenetic->new(
    popSize     => 20,
    crossProb   => 0.8,
    mutProb     => 0.05,
    type        => 'ListVector',
    myFitness   => \&fitness,
);

$algorithm->initialize( [qw/red blue green/], [qw/big medium small/],
    [qw/very_fat fat fit thin very_thin/] );

$algorithm->evolve(
    selection   => "tournament",
    crossover   => "onepoint",
    generations => 20
);

$ind = $algorithm->getFittest();
$genotype = $ind->getGenotype();

print "Score of fittest: \t", $ind->getScore(), "\n";

print "Genotype of fittest: \t";

for ( $i = 0; $i < $genotype->getLength(); $i++ ){
    print $genotype->getGen($i), " ";
}

print "\n";